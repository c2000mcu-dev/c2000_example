#include "DSP28x_Project.h"						// Device Headerfile and Examples Include File

#define DEDAY_VALUE				20000000	

Uint16 I2CA_WData(Uint16 SAddr, Uint16 NumOfByte, Uint16 *Data);
interrupt void i2c_int1a_isr(void);

// Global variables used in this system
Uint16 TxBuff[16];
Uint16 RxBuff[16];
Uint16 I2C_IntSource;
Uint32 i,j;

Uint16 I2C_ErrorCount;
Uint16 I2C_IntCount;
Uint32 LoopCount;

void main(void)
{
//============================================================================================
// Step 1. Disable Global Interrupt
//--------------------------------------------------------------------------------------------
	DINT;
//============================================================================================


//============================================================================================
// Step 2. �ý��� ��Ʈ�� �ʱ�ȭ:
//--------------------------------------------------------------------------------------------
	InitSysCtrl();
//============================================================================================


//============================================================================================
// Step 3. ���ͷ�Ʈ �ʱ�ȭ:
//--------------------------------------------------------------------------------------------
	InitPieCtrl();
	IER = 0x0000;
	IFR = 0x0000;
	InitPieVectTable();

	// Vector Remapping      
	EALLOW;
	PieVectTable.I2CINT1A = &i2c_int1a_isr;
	EDIS;
//============================================================================================

   
//============================================================================================
// Step 4. LED setting
//-------------------------------------------------------------------------------------------- 
	EALLOW;
	GpioCtrlRegs.GPAMUX1.all = 0x00000000;  //  0~15 port use to GPIO
	GpioCtrlRegs.GPAMUX2.all = 0x00000000;  // 16~31 port use to GPIO 
	GpioCtrlRegs.GPADIR.all = 0x000085CA;   // GPIO 1,3,6,7,8,10,15 outputs
   	GpioDataRegs.GPASET.all = 0x000005CA;	// GPIO 1,3,6,7,8,10 high (LED OFF)
	GpioDataRegs.GPACLEAR.all = 0x00008000;	// GPIO 15 low (U3100-74LVC4245A Enable)
   	EDIS;
//============================================================================================


//============================================================================================
// Step 5. I2C setting
//-------------------------------------------------------------------------------------------- 
	// Initialize I2-A PIN
	InitI2CGpio();							// GPIO�� I2C ��� ������ ����

	// Initialize internal I2C peripheral module
	I2caRegs.I2CMDR.bit.IRS = 0;
	I2caRegs.I2CPSC.all = 9;				// Prescaler - need 7-12 Mhz on module clk
	I2caRegs.I2CCLKL = 10;					// NOTE: must be non zero
	I2caRegs.I2CCLKH = 5;					// NOTE: must be non zero
	I2caRegs.I2COAR = 0x01;
	I2caRegs.I2CIER.bit.SCD = 1;			// Enable SCD interrupts
	I2caRegs.I2CFFTX.all = 0x6000;			// Enable FIFO mode and TXFIFO
	I2caRegs.I2CFFRX.all = 0x2040;			// Enable RXFIFO, clear RXFFINT,
	I2caRegs.I2CMDR.bit.IRS = 1;

	// PIE�� ADC ���ͷ�Ʈ Ȱ��ȭ
	PieCtrlRegs.PIEIER8.bit.INTx1 = 1;				// PIE ���ͷ�Ʈ(I2CINT1A) Ȱ��ȭ
	IER |= M_INT8; 									// CPU ���ͷ�Ʈ(INT8)  Ȱ��ȭ
//============================================================================================


//============================================================================================
// Step 6. Initialize Application Variables
//-------------------------------------------------------------------------------------------- 
	for(i=0;i<16;i++){
		TxBuff[i] = i;
	}
	for(i=0;i<16;i++){
		RxBuff[i] = 0;
	}
	I2C_ErrorCount=0;
	I2C_IntCount=0;
	LoopCount=0;
//============================================================================================


//============================================================================================ 
// Enable global Interrupts and higher priority real-time debug events:
//--------------------------------------------------------------------------------------------
	EINT;   // Enable Global interrupt INTM
	ERTM;   // Enable Global realtime interrupt DBGM
//============================================================================================ 


//============================================================================================
// Step 6. IDLE loop. Just sit and loop forever :
//--------------------------------------------------------------------------------------------
	for(;;)
	{
		/*---------------------------------------------------------------------------
			A. I2C ������ �۽�
		---------------------------------------------------------------------------*/	
		while( I2CA_WData(0x01, 16, TxBuff) != I2C_SUCCESS );

		
		/*---------------------------------------------------------------------------
			B. ���� �ֱ�� �����͸� �����ϱ� ���� ������
		---------------------------------------------------------------------------*/	
		for(i=0;i<DEDAY_VALUE;i++);

		
		/*---------------------------------------------------------------------------
			C. ������� �ۼ��ŵ����͸� ����
		---------------------------------------------------------------------------*/
		for(i=0;i<16;i++){
			if(TxBuff[i]!=RxBuff[i])
				I2C_ErrorCount++;
		}

		
		/*---------------------------------------------------------------------------
			D. ������ �۽��� �����͸� ����
		---------------------------------------------------------------------------*/
		for(i=0;i<16;i++){
			TxBuff[i] += 1;
			TxBuff[i] &= 0xFF;
		}

		LoopCount++;

	}
//============================================================================================
} 	
//============================================================================================
//	���� �Լ� - �� 
//============================================================================================


//============================================================================================
//	Local Function : I2C�� �����͸� �۽��ϱ� ���� �Լ�
//--------------------------------------------------------------------------------------------
//  SAddr: �����͸� �۽��� Slave Adress �Է�
//	NumOfByte: �ѹ��� �۽��� Byte �� �Է� (1~16���� ���� ����)
// 	*Data: �۽��� �������� �ּҰ� �Է�
//--------------------------------------------------------------------------------------------
Uint16 I2CA_WData(Uint16 SAddr, Uint16 NumOfByte, Uint16 *Data)
{
	// Wait until the STP bit is cleared from any previous master communication.
	// Clearing of this bit by the module is delayed until after the SCD bit is
	// set. If this bit is not checked prior to initiating a new message, the
	// I2C could get confused.
	if (I2caRegs.I2CMDR.bit.STP == 1){
		return I2C_STP_NOT_READY_ERROR;
	}

	// Bus busy ���¸� üũ
	if (I2caRegs.I2CSTR.bit.BB == 1){
		return I2C_BUS_BUSY_ERROR;
	}

	// ������ �������� Slave Address ���� 
	I2caRegs.I2CSAR = SAddr;	
	
	// ������ �������� Byte ���� ���� 
	I2caRegs.I2CCNT = NumOfByte;

	// ������ �����͸� I2C(FIFO)�� ����  
	for(i=0 ; i<NumOfByte ; i++){
		I2caRegs.I2CDXR = *(Data+i);
	}

	// Master Transmitter ���� ������ ���� (Digital LoopBack ��� ���)
	I2caRegs.I2CMDR.all = 0x2E20;

	return I2C_SUCCESS;
}
//============================================================================================


//============================================================================================
//	Local Interrupt Service Routine : I2C ���ͷ�Ʈ ���� ��ƾ
//--------------------------------------------------------------------------------------------
//	I2CIER �������Ϳ� Enable ������ ���ͷ�Ʈ�� �߻��ϸ� ���� 
//  ���� ������ ������ Stop Coditiond�� �߰ߵ� ���� ���ͷ�Ʈ �߻�
//--------------------------------------------------------------------------------------------
interrupt void i2c_int1a_isr(void)  
{
	Uint16 NumOfByte;

	// Read interrupt source
	I2C_IntSource = I2caRegs.I2CISRC.all;

	NumOfByte = I2caRegs.I2CFFRX.bit.RXFFST; 
	
	// FIFO�� ���ŵ� �����͸� �޸𸮿� ���� 
	for(i=0 ; i<NumOfByte ; i++){
		RxBuff[i] = I2caRegs.I2CDRR;
	}

	I2C_IntCount++;

	// Enable future I2C (PIE Group 8) interrupts
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP8;
}
//============================================================================================

