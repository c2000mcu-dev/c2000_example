#ifndef __F2833x_PWMOUTDRV_H__
#define __F2833x_PWMOUTDRV_H__
#include "DSP2833x_EPwm_defines.h"

typedef struct {
		Uint16	ChSel;
		Uint32	PeriodMax;       
		float32	DutyFuncA;
		float32	DutyFuncB;           
		Uint16	SyncMaster;
		Uint32	Phase;
		Uint16	HrPwmMode;
		int16	MEP_SF;	
		void(*init)();     
		void(*update)();
        } PWMOUTDRV ;   

typedef PWMOUTDRV *PWMOUTDRV_handle;

#define F2833X_PWM_OUT_DRV	{	1,		\
								15000,	\
								0.0,	\
								0.0,	\
								1,		\
								0x0000,	\
								0,		\
								66,		\
								(void (*)(Uint32))F2833X_PwmOut_Init,	\
								(void (*)(Uint32))F2833X_PwmOut_Update	\
							}


#define PWMOUTDRV_DEFAULTS 	F2833X_PWM_OUT_DRV

void F2833X_PwmOut_Init(PWMOUTDRV_handle);
void F2833X_PwmOut_Update(PWMOUTDRV_handle);

#endif 
