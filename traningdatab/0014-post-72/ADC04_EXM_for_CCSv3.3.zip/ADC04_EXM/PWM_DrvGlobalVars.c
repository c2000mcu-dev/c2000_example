//----------------------------------------------------------------------------------
//	FILE:			PWM_DrvGlobalVars.C
//
//	Description:	Contains shared global variables for the PWM drivers
//					converter driver
//
//	Version: 		1.00
//
//  Target:  		TMS320F280x 
//
//	Type: 			Device dependent
//
//----------------------------------------------------------------------------------
//  Copyright Texas Instruments � 2004-2005                                				
//----------------------------------------------------------------------------------
//  Revision History:
//----------------------------------------------------------------------------------
//  Date	  | Description
//----------------------------------------------------------------------------------
//  06/30/05  | Release 1.0  		New release.
//----------------------------------------------------------------------------------
#include "DSP2833x_Device.h"     	// DSP280x Headerfile Include File
#include "DSP2833x_EPWM_defines.h"	// useful defines for initialization


volatile struct EPWM_REGS *ePWM[] = 
 				  { &EPwm1Regs,
					&EPwm1Regs,
					&EPwm2Regs,
					&EPwm3Regs,
					&EPwm4Regs,
					&EPwm5Regs,
					&EPwm6Regs
					};

