1. Setup.msi 로 설치 오류시
2. COMM_PC를 압축해제합니다.
3. 압축해제한 폴더를 c:\SyncWorks\COMM_PC\ 폴더에 옮기면 설치가 완료됩니다.